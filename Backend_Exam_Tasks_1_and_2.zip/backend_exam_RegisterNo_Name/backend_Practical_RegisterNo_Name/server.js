// TASK 2: Student Portal with Login and Protected Routes
// Run: npm run start:task2
require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const authRoutes = require("./routes/auth");
const studentRoutes = require("./routes/students");

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());

app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 100,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { message: "Too many requests. Please try again later." }
}));

app.get("/", (req, res) => res.status(200).json({ message: "Student Portal API is running" }));
app.use("/", authRoutes);
app.use("/students", studentRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 11000) return res.status(400).json({ message: "Email already registered." });
  if (err.name === "ValidationError") return res.status(400).json({ message: err.message });
  res.status(500).json({ message: "Internal server error" });
});

const PORT = process.env.PORT || 3000;
mongoose.connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, () => console.log(`Task 2 server running on port ${PORT}`)))
  .catch(err => {
    console.error("MongoDB connection failed:", err.message);
    process.exit(1);
  });
