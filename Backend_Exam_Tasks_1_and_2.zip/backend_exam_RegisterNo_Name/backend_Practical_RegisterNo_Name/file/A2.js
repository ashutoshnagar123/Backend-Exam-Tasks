// TASK 2 entry point.
// The implementation is organized in server.js, models/, routes/ and middleware/.
// Run from the project root with: npm run start:task2
require("../server");
