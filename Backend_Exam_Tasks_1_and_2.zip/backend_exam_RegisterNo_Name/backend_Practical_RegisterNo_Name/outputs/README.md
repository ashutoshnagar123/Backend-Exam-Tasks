# Output screenshots

Save your own screenshots in this folder after running and testing the APIs.

Suggested filenames:
- A1.png — Task 1 API tests (create, list, get one, update, delete) and MongoDB Compass
- A2.png — Task 2 register/login, profile with and without token, students as admin and student

Do not submit placeholder screenshots. Capture the real responses from Postman or Thunder Client and your MongoDB Compass collections.
