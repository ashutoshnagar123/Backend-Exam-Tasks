const express = require("express");
const User = require("../models/User");
const { authMiddleware, adminOnly } = require("../middleware/authMiddleware");

const router = express.Router();

// GET /students - admin only
router.get("/", authMiddleware, adminOnly, async (req, res, next) => {
  try {
    const students = await User.find().select("name email role createdAt");
    res.status(200).json({ count: students.length, students });
  } catch (error) { next(error); }
});

module.exports = router;
