# Backend Practical Exam — Task 1 and Task 2

This project contains:
- **A1.js:** Library Book Management REST API (Express + MongoDB/Mongoose)
- **A2 implementation:** Student Portal API with registration, login, JWT authentication and protected routes

## 1. Requirements
Install Node.js, MongoDB Community Server (or use a MongoDB Atlas connection), and Postman or Thunder Client.

## 2. Setup
Open this project folder in VS Code or a terminal and run:

```bash
npm install
```

Copy `.env.example` to a new file named `.env`. Set your MongoDB connection string and a long private JWT secret. Example for local MongoDB:

```env
PORT=3000
MONGO_URI=mongodb://127.0.0.1:27017/backend_exam
JWT_SECRET=put_a_long_random_secret_here
```

Keep `.env` private; it is excluded by `.gitignore`.

## 3. Run Task 1
```bash
npm run start:task1
```
Base URL: `http://localhost:3000`

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/books` | Add a book |
| GET | `/books` | List all books |
| GET | `/books/:id` | Get one book |
| PUT | `/books/:id` | Update a book |
| DELETE | `/books/:id` | Delete a book |

Example POST JSON:
```json
{
  "title": "Wings of Fire",
  "author": "A. P. J. Abdul Kalam",
  "price": 250,
  "category": "Biography",
  "isAvailable": true
}
```
The `title` and `author` are required; `price` must be at least 1; `isAvailable` defaults to `true`.

## 4. Run Task 2
Stop Task 1 first (both tasks use port 3000), then run:
```bash
npm run start:task2
```
Base URL: `http://localhost:3000`

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/register` | Register a student or admin |
| POST | `/login` | Login and receive a JWT |
| GET | `/profile` | View current user's profile (token required) |
| GET | `/students` | List users (admin token required) |

### Register JSON
```json
{
  "name": "Demo Student",
  "email": "student@example.com",
  "password": "student123",
  "role": "student"
}
```
For the admin test, register another account with `"role": "admin"`.

### Login JSON
```json
{
  "email": "student@example.com",
  "password": "student123"
}
```
Copy the returned token. For protected requests, add this header:
```text
Authorization: Bearer YOUR_TOKEN_HERE
```

### Expected access
- `/profile` without a token: **401**
- `/profile` with a valid token: **200**
- `/students` with a student token: **403**
- `/students` with an admin token: **200**

Passwords are hashed with bcrypt before storage. JWT tokens expire after one hour. Helmet, CORS and a rate limiter are enabled.

**Security note:** For a real deployed system, admin account creation should be restricted to an existing administrator or a private invite/secret. This practical accepts the `role` field as specified in the assignment for demonstration.

## 5. Folder structure
```text
backend_exam_RegisterNo_Name/
└── backend_Practical_RegisterNo_Name/
    ├── file/
    │   ├── A1.js
    │   └── A2.js
    ├── models/
    │   └── User.js
    ├── routes/
    │   ├── auth.js
    │   └── students.js
    ├── middleware/
    │   └── authMiddleware.js
    ├── outputs/
    │   └── README.md
    ├── server.js
    ├── package.json
    ├── .env.example
    ├── .gitignore
    └── README.md
```

`file/A2.js` is a small launcher for the modular Task 2 implementation; run Task 2 using `npm run start:task2` from the project root.

## 6. Submission screenshots
Run each endpoint in Postman or Thunder Client and save genuine screenshots in `outputs/`. Also open MongoDB Compass and capture the `books` and `users` collections. Do not upload your `.env` file or database password to GitHub.
