Rename this outer folder to backend_exam_YOUR_REGISTER_NUMBER_YOUR_NAME.
Then open backend_Practical_RegisterNo_Name in VS Code.
See its README.md for setup, run commands, API routes and screenshot instructions.
